// API 주소
export const API_HOST = process.env.NEXT_PUBLIC_API_HOST;

// 실행중인 모드
export const MODE = process.env.NEXT_PUBLIC_MODE;