import { NextPage } from 'next';
import React from 'react';
import styled from 'styled-components';

const Container = styled.div`
//   width: 100vw;
  width: 100%;
  height: 100vw;
//   height: 100%;
  align-items: center;
  justify-content:center;
  flex-direction: column;
  display: flex;
  font-size: 20px;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 0;
  padding: 5px 20px;
  box-sizing: border-box;
  font-weight: 600;
  width: 100%;
  height: 14%;
  font-size: 1em;
  & button {
    margin: 0 25px;
    cursor: pointer;
    outline: none;
    display: inline-flex;
    background: transparent;
    border: none;
    color: #444078;
    font-size: 1.2em;
    padding: 4px;
    &:hover {
      color: #fff;
    }
    &:active {
    }
  }
`;
const Days = styled.div`
  background-color: #fff;
  width: 93%;
  height: 81%;
  padding: 8px 10px;
  box-sizing: border-box;
  color: #787c9c;
  margin: 0;
  border-radius: 5px;
  font-size: 0.8em;
`;
const Day = styled.div`
  width: 100%;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  & div {
    min-width: 13%;
    max-height: 5%;
    text-align: center;
    font-weight: 600;
    box-sizing: border-box;
  }
`;

const Row = styled.div`
  width: 100%;
  height: 16%;
  display: flex;
  justify-content: center;
  & div {
    width: 13%;
    height: 100%;
    font-weight: 600;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
  }
  & span {
    margin: 3px 0 0 3px;
    font-size: 0.8em;
    justify-content: flex-start;
    margin-right: 80%;
  }
`;

const Block = styled.div`
    border: 1px solid black;
    backgroundSize: 'contain';
    backgroundPosition: 'center';
    backgroundRepeat: 'no-repeat';
    cursor: 'pointer';
`;

const ScheduleBlock = {
    height: "20%",
    width: "100%",
    minHeight: "11px",
    backgroundColor: "#112667",
    overFlow: "hidden",
    textOverFlow: "ellipsis",
    whiteSpace: "nowrap",
    color: "#fff",
    padding: "1px",
    margin: "0",
    fontSize: "0.5em",
    cursor:"pointer",
};

const Calendar: NextPage = () => {
    return (
        <Container>
            <Header>
                <button>◀</button>
                <span>
                    2022년 02월 18일 금요일
                </span>
                <button>▶</button>
            </Header>
            <Days>
                <Day>
                    <div key={'sun'} style={{color: 'red'}}>일</div>
                    <div key={'mon'} style={{color: 'black'}}>월</div>
                    <div key={'tues'} style={{color: 'black'}}>화</div>
                    <div key={'wen'} style={{color: 'black'}}>수</div>
                    <div key={'thur'} style={{color: 'black'}}>목</div>
                    <div key={'fri'} style={{color: 'black'}}>금</div>
                    <div key={'sat'} style={{color: 'blue'}}>토</div>
                </Day>
            </Days>

            {/* 달력 */}
                <Row>
                    {[1,2,3,4,5,6,7].map((e) => {
                        return (
                        <Block>
                            {e}
                        </Block>
                    )}
                    )}
                </Row>
                <Row>
                    {[1,2,3,4,5,6,7].map((e) => {
                        return (
                        <Block>
                            {e}
                        </Block>
                    )}
                    )}
                </Row>
                <Row>
                    {[1,2,3,4,5,6,7].map((e) => {
                        return (
                        <Block>
                            {e}
                        </Block>
                    )}
                    )}
                </Row>
                <Row>
                    {[1,2,3,4,5,6,7].map((e) => {
                        return (
                        <Block>
                            {e}
                        </Block>
                    )}
                    )}
                </Row>
            {/* 달력 끝 */}

        </Container>
    );
};

export default Calendar;